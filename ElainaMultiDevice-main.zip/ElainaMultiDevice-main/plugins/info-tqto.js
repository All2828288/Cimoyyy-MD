// Jgn Di Hapus
let handler = async (m) => {

let anu =`
⟥⟞⟚━┈┈ ❨  Info Tqto ❩ ┈┈━⟚⟝⟤ 

*Rᴇᴄᴏᴅᴇ Bʏ* : Aʀɪʟ
*Wᴀ Owɴᴇʀ* : wa.me//6282220427314
*Sᴄ Bᴀsᴇ* : Zyko
*Sᴄ Oʀɪ* : wa.me//6283874330385
*Mʏ Pʀᴏᴊᴇᴄᴛ* : 22 𝐴𝑔𝑢𝑠𝑡𝑢𝑠 2023


⫹❰⫺ Bɪɢ Tʜᴀɴᴋs Tᴏ ⫹❱⫺
⭝ Aʟʟᴀʜ Yᴀɴɢ Mᴀʜᴀ Esᴀ
⭝ Oʀᴀɴɢ Tᴜᴀ
⭝ Tᴇᴍᴇɴ Gᴡ
⭝ Mᴀsᴛᴀʜ - Mᴀsᴛᴀʜ

⫹⫺ Tʜᴇ Nᴀᴍᴇ Tʜᴀᴛ Hᴇʟᴘᴇᴅ Mᴇ ⫹⫺
⸔⸔⸔⸔⸔⸔⸔⸔⸔⸔⸔⸔⸔⸔⸔⸔⸔⸔⸔⸔
⭝ Aᴅɪᴡᴀᴊɪsʜɪɴɢ
⭝ Nᴀʀᴜᴛᴏᴍᴏ
⭝ Jᴀʀᴏᴛ Oғᴄ
⭝ Lorenzo
⭝ WH-MODS-DEV
⭝ Hʏᴢᴇʀ
⭝ Dᴇғғʀɪ
⭝ KᴀɴɴᴀCʜᴀɴ
⭝ Cʜʀɪsᴛɪᴀɴ Iᴅ
⭝ Aɪɴᴇ
⭝ Fᴏᴋᴜs Iᴅ
⭝ Aʀɪғғʙ
⭝ Iʟᴍᴀɴ
⭝ Kʀɪʏᴢɴ
⭝ Aʟᴅɪ Lᴇsᴍᴀɴᴀ
⭝ Wʜ Mᴏᴅs Dᴇᴠ
⭝ Eʟᴀɪɴᴀ
⭝ Zyko
⭝ Aᴍɪʀᴜʟ
⭝ Isᴛɪᴋᴍᴀʟ
⭝ Fᴢᴏɴᴇ
⭝ Fᴀᴊᴀʀ
⭝ Aʀᴜʟʟ Oғᴄ
⭝ Zᴇᴇᴏɴᴇ Oғᴄ
⭝ Rᴀᴍʟᴀɴ
⭝ GᴇᴍᴘʏTᴏɴ
⭝ M𝙰𝚁𝚂𝙰𝙽𝙳𝙸
⭝ 𝚂𝙷𝙴𝙽𝙳𝚈
⭝ 𝙷𝙴𝙽zzXD
⭝ Aʀɪʟ Mᴅ


⌕ ❙❘❙❙❘❙❚❙❘❙❙❚❙❘❙❘❙❚❙❘❙❙❚❙❘❙❙❘❙❚❙❘ ⌕

${botdate}
`
await m.reply(anu)
}
handler.help = ['tqto', 'credit']
handler.tags = ['info']
handler.command = /^(tqto|credit)$/i

export default handler

// Yang Hapus Anak Kntolll